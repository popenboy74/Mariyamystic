import React from "react";

interface TarotSymbolProps {
  symbol: "sun" | "moon" | "star" | "pentacle" | "wand" | "cup" | "sword" | "divider";
  size?: "sm" | "md" | "lg";
  className?: string;
}

export default function TarotSymbol({ symbol, size = "md", className = "" }: TarotSymbolProps) {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-6 h-6",
    lg: "w-10 h-10",
  };

  const renderSymbol = () => {
    switch (symbol) {
      case "sun":
        return (
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={`${sizeClasses[size]} ${className}`}>
            <circle cx="12" cy="12" r="5" stroke="currentColor" strokeWidth="2" />
            <path d="M12 2V4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M12 20V22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M4 12L2 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M22 12L20 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M19.7782 4.22183L18.364 5.63604" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M5.63604 18.364L4.22183 19.7782" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M19.7782 19.7782L18.364 18.364" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M5.63604 5.63604L4.22183 4.22183" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        );
      case "moon":
        return (
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={`${sizeClasses[size]} ${className}`}>
            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        );
      case "star":
        return (
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={`${sizeClasses[size]} ${className}`}>
            <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        );
      case "pentacle":
        return (
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={`${sizeClasses[size]} ${className}`}>
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
            <path d="M12 2L7 17H19L14 7H10L15 22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        );
      case "wand":
        return (
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={`${sizeClasses[size]} ${className}`}>
            <path d="M12 2L12 22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M17 4L7 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M15 8L9 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M15 16L9 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M17 20L7 20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        );
      case "cup":
        return (
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={`${sizeClasses[size]} ${className}`}>
            <path d="M7 2H17V10C17 13.3137 14.3137 16 11 16H13C9.68629 16 7 13.3137 7 10V2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M5 22H19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M12 16V22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        );
      case "sword":
        return (
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={`${sizeClasses[size]} ${className}`}>
            <path d="M12 2L12 22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M8 6L16 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M4 10L20 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M7 18L17 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        );
      case "divider":
        return (
          <div className={`relative flex items-center ${className}`}>
            <div className="flex-grow border-t border-accent/30"></div>
            <div className="mx-4 flex-shrink-0 text-accent">✦</div>
            <div className="flex-grow border-t border-accent/30"></div>
          </div>
        );
      default:
        return <span className={`${sizeClasses[size]} ${className}`}>✦</span>;
    }
  };

  return renderSymbol();
}
