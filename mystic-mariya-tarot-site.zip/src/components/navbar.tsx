import Link from "next/link";
import Image from "next/image";

export default function Navbar() {
  return (
    <header className="mystic-header sticky top-0 z-50 w-full">
      <div className="mystic-container">
        <nav className="mystic-navbar">
          <div className="mystic-logo">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-primary text-xl">✦</span>
            </div>
            <span className="mystic-logo-text">Mystic Mariya</span>
          </div>
          <div className="mystic-nav-links">
            <Link href="/" className="mystic-nav-link mystic-nav-link-active">
              Home
            </Link>
            <Link href="/booking" className="mystic-nav-link">
              Book a Reading
            </Link>
            <Link href="/queue" className="mystic-nav-link">
              View Queue
            </Link>
            <Link href="/admin" className="mystic-nav-link">
              Admin
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
