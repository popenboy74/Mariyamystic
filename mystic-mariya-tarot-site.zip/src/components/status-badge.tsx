import React from "react";
import TarotSymbol from "./tarot-symbol";

interface StatusBadgeProps {
  status: "Booked" | "In Progress" | "Done";
  className?: string;
}

export default function StatusBadge({ status, className = "" }: StatusBadgeProps) {
  const getStatusClass = () => {
    switch (status) {
      case "Booked":
        return "status-booked";
      case "In Progress":
        return "status-in-progress";
      case "Done":
        return "status-done";
      default:
        return "status-booked";
    }
  };

  const getStatusSymbol = () => {
    switch (status) {
      case "Booked":
        return "star";
      case "In Progress":
        return "moon";
      case "Done":
        return "sun";
      default:
        return "star";
    }
  };

  return (
    <span className={`${getStatusClass()} flex items-center gap-1 ${className}`}>
      <TarotSymbol symbol={getStatusSymbol() as any} size="sm" />
      <span>{status}</span>
    </span>
  );
}
