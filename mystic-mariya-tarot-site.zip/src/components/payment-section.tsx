"use client";

import React from "react";
import TarotSymbol from "./tarot-symbol";

interface PaymentSectionProps {
  amount: number;
  onTransactionIdChange: (id: string) => void;
  visible: boolean;
}

export default function PaymentSection({
  amount,
  onTransactionIdChange,
  visible
}: PaymentSectionProps) {
  if (!visible) return null;
  
  return (
    <div className="mystic-payment-qr mt-6 animate-in fade-in duration-300">
      <h3 className="mystic-h3 text-center mb-4">Payment Details</h3>
      
      <div className="flex flex-col md:flex-row gap-6 items-center">
        <div className="flex-1">
          <div className="mystic-payment-info">
            <p className="font-medium">Amount: <span className="text-primary font-bold">₹{amount}</span></p>
            <p className="text-sm mt-2">Please scan the QR code to make your payment using any UPI app.</p>
          </div>
          
          <div className="mt-4">
            <label htmlFor="transactionId" className="mystic-label block mb-2">
              Transaction ID <span className="text-destructive">*</span>
            </label>
            <input
              type="text"
              id="transactionId"
              className="mystic-input"
              placeholder="e.g. UPI123456789"
              onChange={(e) => onTransactionIdChange(e.target.value)}
              required
            />
            <p className="text-xs text-muted-foreground mt-1">
              Enter the transaction ID from your UPI payment app
            </p>
          </div>
        </div>
        
        <div className="flex-shrink-0">
          <div className="relative w-[200px] h-[200px] mx-auto">
            <img
              src="/images/qr-code.jpg"
              alt="Payment QR Code"
              className="w-full h-full object-contain rounded-md"
            />
          </div>
        </div>
      </div>
      
      <div className="flex justify-center mt-4">
        <TarotSymbol symbol="divider" className="w-full" />
      </div>
    </div>
  );
}
