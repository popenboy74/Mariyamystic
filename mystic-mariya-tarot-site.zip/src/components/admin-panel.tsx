"use client";

import React from "react";
import { useState } from "react";
import StatusBadge from "@/components/status-badge";
import TarotSymbol from "@/components/tarot-symbol";
import { getReadingTypeLabel } from "@/lib/utils";

export default function AdminPanel() {
  const [password, setPassword] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [paymentFilter, setPaymentFilter] = useState("all");
  const [loginError, setLoginError] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    setLoginError("");

    if (password === "mariya@1234") {
      setIsLoggedIn(true);
      loadBookings();
    } else {
      setLoginError("Invalid password. Please try again.");
    }
  };

  const loadBookings = () => {
    setLoading(true);
    setError("");

    try {
      // In a real implementation, this would be an API call
      // For now, we'll load from localStorage
      const storedBookings = JSON.parse(localStorage.getItem("bookings") || "[]");
      setBookings(storedBookings);
      setLoading(false);
    } catch (error) {
      console.error("Error loading bookings:", error);
      setError("Failed to load booking data");
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    loadBookings();
  };

  const handleStatusChange = (bookingIndex, newStatus) => {
    try {
      const updatedBookings = [...bookings];
      updatedBookings[bookingIndex].status = newStatus;
      setBookings(updatedBookings);
      
      // Update localStorage
      localStorage.setItem("bookings", JSON.stringify(updatedBookings));
      
      // Show toast or notification here
    } catch (error) {
      console.error("Error updating status:", error);
      setError("Failed to update booking status");
    }
  };

  const handleVerifyPayment = (bookingIndex) => {
    try {
      const updatedBookings = [...bookings];
      updatedBookings[bookingIndex].paymentVerified = true;
      setBookings(updatedBookings);
      
      // Update localStorage
      localStorage.setItem("bookings", JSON.stringify(updatedBookings));
      
      // Show toast or notification here
    } catch (error) {
      console.error("Error verifying payment:", error);
      setError("Failed to verify payment");
    }
  };

  const applyFilters = () => {
    try {
      // Get all bookings from localStorage
      const allBookings = JSON.parse(localStorage.getItem("bookings") || "[]");
      
      // Apply filters
      const filteredBookings = allBookings.filter(booking => {
        // Status filter
        if (statusFilter !== "all" && booking.status !== statusFilter) {
          return false;
        }
        
        // Payment filter
        if (paymentFilter === "verified" && !booking.paymentVerified) {
          return false;
        } else if (paymentFilter === "pending" && booking.paymentVerified) {
          return false;
        }
        
        return true;
      });
      
      setBookings(filteredBookings);
    } catch (error) {
      console.error("Error applying filters:", error);
      setError("Failed to apply filters");
    }
  };

  // Apply filters when filter values change
  React.useEffect(() => {
    if (isLoggedIn) {
      applyFilters();
    }
  }, [statusFilter, paymentFilter, isLoggedIn]);

  if (!isLoggedIn) {
    return (
      <div className="max-w-md mx-auto">
        <div className="mystic-ornate-border">
          <h2 className="mystic-h2 text-center mb-6">Admin Login</h2>
          
          {loginError && (
            <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6 rounded-r-md">
              <p className="text-red-700">{loginError}</p>
            </div>
          )}
          
          <form onSubmit={handleLogin}>
            <div className="mystic-form-group">
              <label htmlFor="adminPassword" className="mystic-label block mb-2">
                Password
              </label>
              <input
                type="password"
                id="adminPassword"
                className="mystic-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            
            <button type="submit" className="mystic-button-primary w-full py-2 mt-4">
              Login
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="mystic-h2">Manage Bookings</h2>
        
        <div className="flex items-center gap-2">
          <button 
            onClick={handleRefresh} 
            className="mystic-button-secondary px-4 py-2"
          >
            Refresh
          </button>
          
          <button 
            onClick={() => setIsLoggedIn(false)} 
            className="mystic-button-accent px-4 py-2"
          >
            Logout
          </button>
        </div>
      </div>
      
      {error && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6 rounded-r-md">
          <p className="text-red-700">{error}</p>
        </div>
      )}
      
      <div className="bg-secondary/30 p-4 rounded-lg mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <label htmlFor="statusFilter" className="mystic-label block mb-2">
              Status Filter
            </label>
            <select
              id="statusFilter"
              className="mystic-select w-full"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">All Statuses</option>
              <option value="Booked">Booked</option>
              <option value="In Progress">In Progress</option>
              <option value="Done">Done</option>
            </select>
          </div>
          
          <div className="flex-1">
            <label htmlFor="paymentFilter" className="mystic-label block mb-2">
              Payment Filter
            </label>
            <select
              id="paymentFilter"
              className="mystic-select w-full"
              value={paymentFilter}
              onChange={(e) => setPaymentFilter(e.target.value)}
            >
              <option value="all">All Payments</option>
              <option value="verified">Verified</option>
              <option value="pending">Pending</option>
            </select>
          </div>
        </div>
      </div>
      
      {loading ? (
        <div className="text-center py-12">
          <div className="mystic-spinner"></div>
          <p className="text-muted-foreground">Loading booking data...</p>
        </div>
      ) : bookings.length === 0 ? (
        <div className="text-center py-12">
          <TarotSymbol symbol="moon" size="lg" className="text-accent mx-auto mb-4" />
          <h3 className="mystic-h3 mb-2">No Bookings Found</h3>
          <p className="text-muted-foreground">
            There are no bookings matching your current filters.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="mystic-table">
            <thead>
              <tr>
                <th>Instagram ID</th>
                <th>Reading Type</th>
                <th>Transaction ID</th>
                <th>Payment</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking, index) => (
                <tr key={index}>
                  <td>{booking.instagramId}</td>
                  <td>
                    {getReadingTypeLabel(booking.readingType)}
                    {booking.isEmergency && (
                      <span className="mystic-badge-accent ml-2">Emergency</span>
                    )}
                  </td>
                  <td>{booking.transactionId || "N/A"}</td>
                  <td>
                    {booking.transactionId ? (
                      booking.paymentVerified ? (
                        <span className="mystic-badge-primary">Verified</span>
                      ) : (
                        <span className="mystic-badge-outline">Pending</span>
                      )
                    ) : (
                      <span className="text-muted-foreground">N/A</span>
                    )}
                  </td>
                  <td>
                    <StatusBadge status={booking.status} />
                  </td>
                  <td>
                    <div className="flex flex-wrap gap-2">
                      {booking.transactionId && !booking.paymentVerified && (
                        <button
                          onClick={() => handleVerifyPayment(index)}
                          className="mystic-button-primary text-xs px-2 py-1"
                        >
                          Verify Payment
                        </button>
                      )}
                      
                      {booking.status === "Booked" && (
                        <button
                          onClick={() => handleStatusChange(index, "In Progress")}
                          className="mystic-button-accent text-xs px-2 py-1"
                        >
                          Start Reading
                        </button>
                      )}
                      
                      {booking.status === "In Progress" && (
                        <button
                          onClick={() => handleStatusChange(index, "Done")}
                          className="mystic-button-secondary text-xs px-2 py-1"
                        >
                          Complete
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
