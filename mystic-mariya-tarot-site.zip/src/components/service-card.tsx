import React from "react";
import TarotSymbol from "./tarot-symbol";

interface ServiceCardProps {
  title: string;
  description: string;
  price: string;
  symbol: "sun" | "moon" | "star" | "pentacle" | "wand" | "cup" | "sword";
  emergency?: boolean;
  emergencyPrice?: string;
}

export default function ServiceCard({
  title,
  description,
  price,
  symbol,
  emergency = false,
  emergencyPrice,
}: ServiceCardProps) {
  return (
    <div className="mystic-service-card group">
      <div className="mb-4">
        <TarotSymbol symbol={symbol} size="lg" className="text-accent mx-auto" />
      </div>
      <h3 className="mystic-h3 mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
      <div className="mystic-service-price">{price}</div>
      {emergency && emergencyPrice && (
        <div className="text-sm text-muted-foreground">
          Emergency option: <span className="font-semibold text-accent">{emergencyPrice}</span>
        </div>
      )}
      <button className="mystic-button-accent w-full mt-4">Book Now</button>
    </div>
  );
}
