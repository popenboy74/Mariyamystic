import React from "react";
import TarotSymbol from "./tarot-symbol";

interface PageHeaderProps {
  title: string;
  description?: string;
  symbol?: "sun" | "moon" | "star" | "pentacle" | "wand" | "cup" | "sword";
}

export default function PageHeader({
  title,
  description,
  symbol = "star",
}: PageHeaderProps) {
  return (
    <div className="text-center py-8 md:py-12">
      <div className="flex justify-center mb-4">
        <TarotSymbol symbol={symbol} size="lg" className="text-accent" />
      </div>
      <h1 className="mystic-h1 mb-3">{title}</h1>
      {description && (
        <p className="text-muted-foreground max-w-2xl mx-auto">{description}</p>
      )}
      <div className="mt-6">
        <TarotSymbol symbol="divider" className="w-full" />
      </div>
    </div>
  );
}
