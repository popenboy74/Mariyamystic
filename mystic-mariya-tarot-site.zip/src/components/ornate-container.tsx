import React from "react";
import TarotSymbol from "./tarot-symbol";

interface OrnateContainerProps {
  children: React.ReactNode;
  className?: string;
  symbol?: "sun" | "moon" | "star" | "pentacle" | "wand" | "cup" | "sword";
}

export default function OrnateContainer({
  children,
  className = "",
  symbol = "star",
}: OrnateContainerProps) {
  return (
    <div className={`mystic-ornate-border relative ${className}`}>
      <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-background px-4">
        <TarotSymbol symbol={symbol} size="md" className="text-accent" />
      </div>
      <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-background px-4">
        <TarotSymbol symbol={symbol} size="md" className="text-accent" />
      </div>
      <div className="absolute -left-3 top-1/2 -translate-y-1/2 bg-background py-4">
        <TarotSymbol symbol={symbol} size="md" className="text-accent" />
      </div>
      <div className="absolute -right-3 top-1/2 -translate-y-1/2 bg-background py-4">
        <TarotSymbol symbol={symbol} size="md" className="text-accent" />
      </div>
      {children}
    </div>
  );
}
