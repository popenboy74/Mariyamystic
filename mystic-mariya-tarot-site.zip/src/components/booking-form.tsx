"use client";

import React from "react";
import { useState, useEffect } from "react";
import { getReadingPrice, getReadingTypeLabel } from "@/lib/utils";
import PaymentSection from "@/components/payment-section";

export default function BookingForm() {
  const [instagramId, setInstagramId] = useState("");
  const [readingType, setReadingType] = useState("free");
  const [isEmergency, setIsEmergency] = useState(false);
  const [transactionId, setTransactionId] = useState("");
  const [totalAmount, setTotalAmount] = useState(0);
  const [showPayment, setShowPayment] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const [formSuccess, setFormSuccess] = useState("");

  // Calculate total amount when reading type or emergency status changes
  useEffect(() => {
    const amount = getReadingPrice(readingType, isEmergency);
    setTotalAmount(amount);
    setShowPayment(amount > 0);
  }, [readingType, isEmergency]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");
    setFormSuccess("");
    
    // Validate form
    if (!instagramId) {
      setFormError("Please enter your Instagram ID");
      return;
    }
    
    if (showPayment && !transactionId) {
      setFormError("Please enter the transaction ID from your payment");
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // In a real implementation, this would be an API call
      // For now, we'll simulate a successful booking
      
      // Create booking data
      const bookingData = {
        instagramId,
        readingType,
        isEmergency,
        transactionId: transactionId || null,
        paymentVerified: false,
        status: "Booked",
        createdAt: new Date().toISOString()
      };
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Store in localStorage for demo purposes
      const existingBookings = JSON.parse(localStorage.getItem("bookings") || "[]");
      existingBookings.push(bookingData);
      localStorage.setItem("bookings", JSON.stringify(existingBookings));
      
      // Show success message
      setFormSuccess("Booking successful! Check the queue page for your status.");
      
      // Reset form
      setInstagramId("");
      setReadingType("free");
      setIsEmergency(false);
      setTransactionId("");
      
      // Redirect to queue page after 2 seconds
      setTimeout(() => {
        window.location.href = "/queue";
      }, 2000);
    } catch (error) {
      setFormError("An error occurred. Please try again.");
      console.error("Booking error:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
      {formError && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6 rounded-r-md">
          <p className="text-red-700">{formError}</p>
        </div>
      )}
      
      {formSuccess && (
        <div className="bg-green-50 border-l-4 border-green-400 p-4 mb-6 rounded-r-md">
          <p className="text-green-700">{formSuccess}</p>
        </div>
      )}
      
      <div className="mystic-form-group">
        <label htmlFor="instagramId" className="mystic-label block mb-2">
          Instagram ID <span className="text-destructive">*</span>
        </label>
        <input
          type="text"
          id="instagramId"
          className="mystic-input"
          placeholder="@your_instagram_handle"
          value={instagramId}
          onChange={(e) => setInstagramId(e.target.value)}
          required
        />
        <p className="text-xs text-muted-foreground mt-1">
          This will be used to identify you for your reading
        </p>
      </div>
      
      <div className="mystic-form-group">
        <label htmlFor="readingType" className="mystic-label block mb-2">
          Reading Type <span className="text-destructive">*</span>
        </label>
        <select
          id="readingType"
          className="mystic-select"
          value={readingType}
          onChange={(e) => setReadingType(e.target.value)}
          required
        >
          <option value="free">Free Reading</option>
          <option value="paid-10min">10-Minute Reading (₹50)</option>
          <option value="paid-20min">20-Minute Reading + Telepathy (₹75)</option>
          <option value="paid-30min">30-Minute Reading + Telepathy (₹100)</option>
        </select>
      </div>
      
      <div className="mystic-form-group">
        <div className="flex items-center">
          <input
            type="checkbox"
            id="isEmergency"
            className="mystic-checkbox mr-2"
            checked={isEmergency}
            onChange={(e) => setIsEmergency(e.target.checked)}
          />
          <label htmlFor="isEmergency" className="mystic-label">
            Emergency Reading
          </label>
        </div>
        <p className="text-xs text-muted-foreground mt-1 ml-6">
          {readingType === "free" 
            ? "Additional ₹30 for emergency free readings" 
            : "Additional ₹20 for emergency paid readings"}
        </p>
      </div>
      
      <PaymentSection
        amount={totalAmount}
        onTransactionIdChange={setTransactionId}
        visible={showPayment}
      />
      
      <div className="mt-6">
        <button
          type="submit"
          className="mystic-button-primary w-full py-2"
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </span>
          ) : (
            "Book Reading"
          )}
        </button>
      </div>
    </form>
  );
}
