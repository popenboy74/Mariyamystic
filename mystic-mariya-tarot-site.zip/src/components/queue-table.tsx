"use client";

import React from "react";
import StatusBadge from "@/components/status-badge";
import TarotSymbol from "@/components/tarot-symbol";
import { getReadingTypeLabel } from "@/lib/utils";

export default function QueueTable() {
  const [bookings, setBookings] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState("");

  React.useEffect(() => {
    // In a real implementation, this would be an API call
    // For now, we'll load from localStorage
    try {
      const storedBookings = JSON.parse(localStorage.getItem("bookings") || "[]");
      setBookings(storedBookings);
      setLoading(false);
    } catch (error) {
      console.error("Error loading bookings:", error);
      setError("Failed to load queue data");
      setLoading(false);
    }

    // Set up a polling interval to refresh the queue
    const interval = setInterval(() => {
      try {
        const refreshedBookings = JSON.parse(localStorage.getItem("bookings") || "[]");
        setBookings(refreshedBookings);
      } catch (error) {
        console.error("Error refreshing bookings:", error);
      }
    }, 5000); // Refresh every 5 seconds

    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="mystic-spinner"></div>
        <p className="text-muted-foreground">Loading queue data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded-r-md">
        <p className="text-red-700">{error}</p>
      </div>
    );
  }

  if (bookings.length === 0) {
    return (
      <div className="text-center py-12">
        <TarotSymbol symbol="moon" size="lg" className="text-accent mx-auto mb-4" />
        <h3 className="mystic-h3 mb-2">Queue is Empty</h3>
        <p className="text-muted-foreground">
          There are currently no bookings in the queue.
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="mystic-table">
        <thead>
          <tr>
            <th>Position</th>
            <th>Instagram ID</th>
            <th>Reading Type</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((booking, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{booking.instagramId}</td>
              <td>
                {getReadingTypeLabel(booking.readingType)}
                {booking.isEmergency && (
                  <span className="mystic-badge-accent ml-2">Emergency</span>
                )}
              </td>
              <td>
                <StatusBadge status={booking.status} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
