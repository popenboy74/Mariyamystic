import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(price: number): string {
  return `₹${price}`;
}

export function getReadingTypeLabel(type: string): string {
  switch (type) {
    case "free":
      return "Free Reading";
    case "paid-10min":
      return "10-Minute Reading";
    case "paid-20min":
      return "20-Minute Reading + Telepathy";
    case "paid-30min":
      return "30-Minute Reading + Telepathy";
    default:
      return type;
  }
}

export function getReadingPrice(type: string, isEmergency: boolean = false): number {
  let price = 0;
  
  switch (type) {
    case "free":
      price = 0;
      break;
    case "paid-10min":
      price = 50;
      break;
    case "paid-20min":
      price = 75;
      break;
    case "paid-30min":
      price = 100;
      break;
    default:
      price = 0;
  }
  
  if (isEmergency) {
    if (type === "free") {
      price += 30;
    } else {
      price += 20;
    }
  }
  
  return price;
}

export function generateBookingId(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}
