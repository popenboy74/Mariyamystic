import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import PageHeader from "@/components/page-header";
import AdminPanel from "@/components/admin-panel";

export default function AdminPage() {
  return (
    <main>
      <Navbar />
      
      <div className="mystic-container">
        <PageHeader 
          title="Admin Dashboard" 
          description="Manage bookings, verify payments, and update reading statuses."
          symbol="sword"
        />
        
        <div className="max-w-5xl mx-auto mb-16">
          <AdminPanel />
        </div>
      </div>
      
      <Footer />
    </main>
  );
}
