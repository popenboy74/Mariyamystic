import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import PageHeader from "@/components/page-header";
import QueueTable from "@/components/queue-table";

export default function QueuePage() {
  return (
    <main>
      <Navbar />
      
      <div className="mystic-container">
        <PageHeader 
          title="Current Reading Queue" 
          description="View the current status of all bookings and check your position in the queue."
          symbol="moon"
        />
        
        <div className="max-w-4xl mx-auto mb-16">
          <QueueTable />
        </div>
      </div>
      
      <Footer />
    </main>
  );
}
