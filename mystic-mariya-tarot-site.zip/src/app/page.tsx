import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import PageHeader from "@/components/page-header";
import ServiceCard from "@/components/service-card";
import TarotSymbol from "@/components/tarot-symbol";
import OrnateContainer from "@/components/ornate-container";

export default function Home() {
  return (
    <main>
      <Navbar />
      
      <div className="mystic-container">
        <section className="mystic-hero">
          <div className="mystic-hero-content">
            <h1 className="mystic-h1 mb-6">Discover Your Path with Mystic Mariya</h1>
            <p className="text-lg text-muted-foreground mb-8">
              Unlock the secrets of your past, present, and future through premium tarot reading services.
              Let the cards guide you to clarity, insight, and spiritual awakening.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="/booking" className="mystic-button-primary px-6 py-3">
                Book a Reading
              </a>
              <a href="/queue" className="mystic-button-secondary px-6 py-3">
                View Queue
              </a>
            </div>
          </div>
        </section>
        
        <TarotSymbol symbol="divider" className="w-full my-8" />
        
        <section>
          <PageHeader 
            title="Premium Reading Services" 
            description="Choose from a variety of tarot reading options tailored to your needs"
            symbol="star"
          />
          
          <div className="mystic-services">
            <ServiceCard
              title="Free Reading"
              description="A brief glimpse into your situation with general guidance and insights."
              price="Free"
              symbol="moon"
              emergency={true}
              emergencyPrice="+₹30"
            />
            
            <ServiceCard
              title="10-Minute Reading"
              description="A focused reading addressing specific questions or areas of concern."
              price="₹50"
              symbol="pentacle"
              emergency={true}
              emergencyPrice="+₹20"
            />
            
            <ServiceCard
              title="20-Minute Reading"
              description="In-depth reading with telepathic insights for deeper understanding."
              price="₹75"
              symbol="cup"
              emergency={true}
              emergencyPrice="+₹20"
            />
            
            <ServiceCard
              title="30-Minute Reading"
              description="Comprehensive reading with telepathic insights covering multiple aspects of life."
              price="₹100"
              symbol="sun"
              emergency={true}
              emergencyPrice="+₹20"
            />
          </div>
        </section>
        
        <section className="my-16">
          <OrnateContainer className="text-center py-8" symbol="star">
            <h2 className="mystic-h2 mb-4">Supporting Those in Need</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              50% of all paid readings go towards helping those in need. Your booking not only provides
              you with spiritual guidance but also contributes to making a positive difference in someone's life.
            </p>
          </OrnateContainer>
        </section>
        
        <section className="my-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="mystic-h2 mb-4">About Mystic Mariya</h2>
              <p className="text-muted-foreground mb-4">
                With years of experience in tarot reading and spiritual guidance, Mystic Mariya offers
                insightful and transformative readings that connect you with your higher self and the
                universal energies that shape your journey.
              </p>
              <p className="text-muted-foreground">
                Each reading is conducted with care, empathy, and a deep respect for the ancient wisdom
                of the tarot cards. Whether you seek clarity, guidance, or simply a glimpse into what
                lies ahead, Mystic Mariya is here to illuminate your path.
              </p>
            </div>
            
            <div className="flex justify-center">
              <div className="relative w-64 h-64 rounded-full bg-primary/10 flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border-2 border-accent/20"></div>
                <div className="absolute inset-4 rounded-full border border-accent/10"></div>
                <TarotSymbol symbol="star" size="lg" className="text-accent" />
              </div>
            </div>
          </div>
        </section>
      </div>
      
      <Footer />
    </main>
  );
}
