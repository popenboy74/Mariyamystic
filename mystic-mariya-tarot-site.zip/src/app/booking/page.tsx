import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import PageHeader from "@/components/page-header";
import BookingForm from "@/components/booking-form";

export default function BookingPage() {
  return (
    <main>
      <Navbar />
      
      <div className="mystic-container">
        <PageHeader 
          title="Book Your Reading" 
          description="Select your preferred reading type and provide your details to secure your spot in the queue."
          symbol="pentacle"
        />
        
        <div className="max-w-3xl mx-auto mb-16">
          <BookingForm />
        </div>
      </div>
      
      <Footer />
    </main>
  );
}
